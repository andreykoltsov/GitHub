/*Sources
http://www.thejavageek.com/2013/07/21/using-javac-and-java-commands-to-compile-and-launch-java-programs/
*/

package pack1;

public class class1{
	protected int a=10;
}