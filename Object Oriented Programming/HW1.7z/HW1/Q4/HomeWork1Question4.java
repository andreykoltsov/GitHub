import java.util.*;

public class HomeWork1Question4{
	public static void main(String[] args){
		Scanner inwords = new Scanner(System.in);
		
		while(inwords.hasNext()){
			System.out.println(inwords.nextInt());
		}
	}
}